POI_DISTANCE = 0.5  # unit:km
host = '0.0.0.0'
port = 5000
debug = True
data_file = "东城区poi.csv"