# def least(seq1, seq2):
#     list1 = [];
#     list1.append(seq1);
#     list1.append(seq1);
#     return list1;
# if __name__ == '__main__':
#     seq1 = ['AB', 1];
#     seq2 = ['BC', 2];
#     list1=least(seq1, seq2);
#     print(list1);
# import Topk
#
# def least(list1,path1):
#     t = [];
#     for list in list1:
#         if list1.index(list).index(0) == path1:
#             t.append(list1.index(list).index(1));
#     Topk.partition(t);
#     Topk.select(t, len(t));
#     return
#
# if __name__ == '__main__':
#     list1=[['AB', 1], ['AB', 2]]
#     least(list1,AB)
