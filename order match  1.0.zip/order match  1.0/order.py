import time
import Create
import Lastpath
def match(request1,request2):
    Create.lista()
    Lastpath.lastpath()
    if(request1[0] != request2[0]):
        return 0;
    else:
        if(request1[1] == request2[1]):
            return 1;
        else:
            for i in range(len(Lastpath.lpath)):
                if(request1[0] == Lastpath.lpath[i][0][0] and request1[1] == Lastpath.lpath[i][-1][0]):
                    t = Lastpath.lpath[i][-1][1]-Lastpath.lpath[i][0][1]
                    ##print(t)
            for ii in range(len(Create.listpoi)):
                if(request2[1] == Create.listpoi[ii][0]):
                    for iii in range(len(Lastpath.lpath)):
                        if (request2[1] == Lastpath.lpath[iii][0][0] and request1[1] == Lastpath.lpath[iii][-1][0]):
                            t2 = Lastpath.lpath[iii][-1][1]-Lastpath.lpath[iii][0][1]
                            ##print(t2)
                            if(t2 < t):
                                return 2
                            else:
                                return 0




if __name__ == '__main__':
    var = 1
    while var == 1:
        a = input('Please enter package departure:');
        b = input('Please enter package destination:');
        request1 = [a, b, time.time()];
        c = input('Please enter passenger departure:');
        d = input('Please enter passenger destination:');
        request2 = [c, d, time.time()];

        if (match(request1, request2) == 1):
            print("match successfully!")
        elif (match(request1, request2) == 2):
            print("match successful(transfer station)")
        else:
            print("match fail")
